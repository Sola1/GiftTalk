package com.sola.gifttalk.activity;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.sola.gifttalk.R;
import com.sola.gifttalk.bean.GiftReuseBean;
import com.sola.gifttalk.tool.BaseViewHoler;
import com.sola.gifttalk.tool.MyApp;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dllo on 17/2/23.
 */

public class GiftContentActivity extends BaseActivity {
    private WebView webView;
    private Banner banner;
    private TextView shortTv, nameTv, priceTv;
    private ScrollView scrollView;

    @Override
    public int bindLayout() {
        return R.layout.activity_giftcontent;
    }

    @Override
    protected void initView() {
        webView = bindView(R.id.web_view_gift);
        banner = bindView(R.id.banner_gift_content);
        shortTv = bindView(R.id.tv_gift_content_short);
        nameTv = bindView(R.id.tv_gift_content_name);
        priceTv = bindView(R.id.tv_gift_content_fixed_price);
        scrollView = bindView(R.id.scroll_view_gift_content);

    }

    @Override
    protected void initData() {

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        // 支持缩放(适配到当前屏幕)
        webSettings.setSupportZoom(true);

        webView.setInitialScale(100);

        // 将图片调整到合适的大小
        webSettings.setUseWideViewPort(true);

        String url = getIntent().getStringExtra("giftContentUrl");
        webView.loadDataWithBaseURL(null, url, "text/html", "utf-8", null);

        String title = getIntent().getStringExtra("title");
        String name = getIntent().getStringExtra("name");
        ArrayList<String> images = getIntent().getStringArrayListExtra("images");
        String price = getIntent().getStringExtra("price");

        shortTv.setText(title);
        nameTv.setText(name);
        priceTv.setText(price);

        banner.setImageLoader(new GlideImageLoader());
        banner.setImages(images);
        banner.isAutoPlay(false);//自动播放
        banner.setIndicatorGravity(BannerConfig.CENTER);//设置小圆点的位置
        banner.start();

    }

    @Override
    protected void bindEvent() {
        //TODO 设置ScrollView的滑动监听事件
        scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                //scrollView.scrollTo(0,300);
            }
        });

    }

    class GlideImageLoader extends ImageLoader {

        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            Glide.with(context).load(path).into(imageView);
        }
    }
}
