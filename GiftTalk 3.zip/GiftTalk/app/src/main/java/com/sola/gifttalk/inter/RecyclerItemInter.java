package com.sola.gifttalk.inter;

/**
 * Created by dllo on 17/2/23.
 */

public interface RecyclerItemInter {
    void onItemJump(int pos);
}
