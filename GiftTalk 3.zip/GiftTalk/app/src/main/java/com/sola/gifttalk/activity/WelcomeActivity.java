package com.sola.gifttalk.activity;

import com.sola.gifttalk.R;

/**
 * Created by dllo on 17/2/21.
 */

public class WelcomeActivity extends BaseActivity {
    @Override
    public int bindLayout() {
        return R.layout.activity_welcome;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void bindEvent() {

    }
}
