package com.sola.gifttalk.fragment;

import com.sola.gifttalk.R;

/**
 * Created by dllo on 17/2/9.
 */

public class ProfileFragment extends BaseFragment {
    @Override
    protected int bindLayout() {
        return R.layout.fragment_profile;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void bindEvent() {

    }
}
